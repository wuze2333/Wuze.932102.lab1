﻿namespace lab12.Models
{
    public record CalculationExpressionModel(int firstNumber, int secondNumber, string operation);
}
